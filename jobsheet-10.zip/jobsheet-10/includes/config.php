<?php

$supabaseUrl = 'https://lggjdyxnbhzcbkntayfa.supabase.co';
$supabaseKey = 'sb_secret_J-TwRYDgDA7We_U3X89cJg_swVQZ0aL';